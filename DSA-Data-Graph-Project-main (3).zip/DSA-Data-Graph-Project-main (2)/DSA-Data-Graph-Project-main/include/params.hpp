#ifndef PARAMS_HPP
#define PARAMS_HPP

constexpr int MAX_EMPLOYEES = 200;

#endif